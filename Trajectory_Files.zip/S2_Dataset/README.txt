The trajectory files created at the end of the simulation when utilising the µbialSim tool for MATLAB are included inside these folders.

Each folder includes the last iteration file for each case analysed in the study.

Inside each folder there is another folder when the hierarchical group are used as stated in the manuscript in Fig 1.